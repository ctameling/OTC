# samples smaller secments from a picture. 
randomsegments2 <- function(pic1, pic2, samplesize = 10, segmentlength = 200, segmentwidth = 200, relmass = 0.8) {
  
  originaldim = dim(pic1)
  
  truncatedlength <- originaldim[1] - segmentlength + 1
  truncatedwidth <- originaldim[2] - segmentwidth + 1
  
  segments1 <- list()
  segments2 <- list()
  i <- 1
  while (i <= samplesize) {
    row <- sample.int(truncatedlength,1) # drawing uniformsample of matrixentries
    column <- sample.int(truncatedwidth,1)
    
    seg1 <- pic1[row:(row + segmentlength -1), column:(column+ segmentwidth -1)]
    seg2 <- pic2[row:(row + segmentlength -1), column:(column+ segmentwidth -1)]
    if (length(which(seg1 > 0)) /(segmentlength * segmentwidth) >= relmass & 
            length(which(seg2 > 0)) / (segmentlength * segmentwidth) >= relmass){
      segments1[[i]] <- seg1
      segments2[[i]] <- seg2
      i <- i + 1 
    }
    
  }
  
  segments <- list(segments1, segments2)
  return(segments) # output: list of lists with segments (same positions) of all matrices
}