#' Do the plotting of the OTC curves
#'
#' @param otc_curves is either a data frame with the columns class, i, t, OTC or a path to a location
#' of RData file that contains such a data frame
#' @param load_data if you want to load data (default FALSE)
#' @param CB if you want to have confidence bands (default TRUE)
#' @param alpha Significance level for confidence bands (default 0.05)
#' @param upper_t upper limit for curves in plot in nm (default 250)
#' @param lower_t lower limit for curves in plot in nm (default 30)
#' @param output_path Path where to save the figures
#' @param output_name name of figure file
#'
# load libraries
library(ggplot2)
library(MASS)

plot_otc_curves <- function(otc_curves, load_data=FALSE, CB=TRUE, alpha = 0.05, upper_t=250, lower_t=30, output_path="", output_name=""){

  # load data if neccessary
  if (load_data){otc_curves <- get(load(otc_curves))}

  # aggregate OTC values by mean
  otc_means <- aggregate(otc_curves$OTC, by = list(otc_curves$class, otc_curves$t), mean)
  colnames(otc_means) <- c("class", "t", "OTC")

  # calculate confidence bands if it is choosen
  if (CB){
    # set part for name
    cb_name = paste("CB_", toString(alpha), "_", sep="")
    # calculate quantiles
    otc_means$quantile = 0

    for (class in unique(otc_curves$class)){
      data <- otc_curves[otc_curves$class == class,]
      n <- length(unique(data$i))
      Ts <- unique(data$t)
      p <- length(Ts)
      df <- data.frame(matrix(ncol = p, nrow = n))
      colnames(df) <- Ts
      for (j in 1:n){
        df[j,]<- data[data$i == j,]$OTC

      }

      df_center <- scale(df, scale=FALSE)

      cov_matrix = matrix(0, p, p)

      for (i in 1:nrow(df_center)){
        cov_matrix = cov_matrix + as.numeric(df_center[i,]) %*% t(as.numeric(df_center[i,]))
      }

      cov_matrix = 1/(n-1) * cov_matrix

      sample = MASS::mvrnorm(n=1000, mu = rep(0, p), Sigma = cov_matrix)
      sample = abs(sample)
      # get sup of each sample
      sups = apply(sample, 1, max)
      alpha = 0.05
      u_alpha = quantile(sups, probs = alpha/2)
      otc_means[otc_means$class == class,]$quantile <- u_alpha

    }

  # calculate upper and lower boundary for CBs
  otc_means$upper <- otc_means$OTC + otc_means$quantile/sqrt(n)
  otc_means$lower <- otc_means$OTC - otc_means$quantile/sqrt(n)

  otc_means$upper_thresh <- 1
  otc_means$lower_thresh <- 0

  otc_means$upper <- apply(otc_means[, c("upper", "upper_thresh")], 1, min)
  otc_means$lower <- apply(otc_means[, c("lower", "lower_thresh")], 1, max)

  otc_means <- subset(otc_means, select = -c(lower_thresh, upper_thresh))
  }else{cb_name = "_"}

  # restrict to t from lower_t to upper_t
  otc_means <- otc_means[otc_means$t >= lower_t & otc_means$t <= upper_t,]

  # open a graphic device
  pdf(file.path(output_path, paste("OTC_curves_",cb_name, output_name, ".pdf", sep = "")), width = 10, height = 7)
  # do the plotting
  p <- ggplot(data = otc_means, aes(x = t, y = OTC, color = class)) +
    geom_line() +
    geom_ribbon(aes(x=t, ymax=upper, ymin=lower, fill = class), alpha=.3) +
    scale_x_continuous(name = "threshold in nm") +
    scale_y_continuous(name = "Optimal Transport Colocalization", lim = c(0,1)) +
    guides(color = guide_legend(title = ""), linetype = guide_legend(title = ""), fill = guide_legend(title = "")) +
    theme(legend.key.height = unit(2, 'lines'), legend.key.width = unit(2, 'lines'))

  # save the plot
  print(p)
  dev.off()
}
