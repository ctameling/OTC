#' A function to calculate a bunch of transport plans.
#'
#' @description
#' This function calculates a bunch of transport plans between two diffenrent pictures
#'
#' @param data_path location to folder that contains the images in tiff format+
#' @param picsA list of names of pictures of type A
#' @param picsB list of names of pictures of type B
#' @param random_section if you want to take random sections of input images
#' @param n_random_section how many random sections from each input image
#' @param section_size size of section in number of pixels, a squared section is taken
#' @param save If you want to save the results, defaults to TRUE
#' @param output_path Where to save the results
#' @param output_name Name of data set, full name will be Tplans_<output_name>.RData
#' @return Returns a list with transport plans



source("./R/otc_utils.R")
source("./R/randomsegments2.R")

calculate_tplans <- function(data_path, picsA, picsB, random_sections=FALSE, n_random_sections=10, section_size=128, output_path="", output_name="", save=TRUE){

  # check if save is true and output_path given
  if (save & output_path==""){stop("Please provide an output_path if you want to save the results!")}

  # check for length in items in picsA and picsB
  n <- length(picsA)
  if (n != length(picsB)){
    stop("Unequal number of pics of type A and B")
  }

  # set up results
  results <- list()

  for (i in 1:n){
    print(paste("Processing", i, "out of", n, "...", sep = " "))

    # read pictures
    # TO-DO Add try and catch maybe?
    picA <- tiff::readTIFF(file.path(data_path, picsA[i]))
    picB <- tiff::readTIFF(file.path(data_path, picsB[i]))

    # convert to grayscale
    picA <- RGBtoGray(picA)
    picB <- RGBtoGray(picB)

    # denoising by thresholding
    picA <- picA * (picA > quantile(picA, probs = 0.05))
    picB <- picB * (picB > quantile(picB, probs = 0.05))

    # normalization
    picA <- picA / sum(picA)
    picB <- picB / sum(picB)

    # denoising by thresholding
    picA <- picA * (picA > quantile(picA, probs = 0.05))
    picB <- picB * (picB > quantile(picB, probs = 0.05))


    # normalization
    picA <- picA / sum(picA)
    picB <- picB / sum(picB)

    # take random section if it is choosen
    if (random_sections){
      segments <- randomsegments2(picA, picB, segmentlength=section_size, segmentwidth=section_size,
                                   samplesize=n_random_sections,
                                   relmass = 5 * min(length(which(picA >0)), length(which(picB>0))) / (dim(picA)[1]*dim(picB)[2]))
      for (j in 1:n){
        snip1 <- as.matrix(segments[[1]][[j]])
        snip2 <- as.matrix(segments[[2]][[j]])

        # normalize snipplets
        snip1 <- snip1 / sum(snip1)
        snip2 <- snip2 / sum(snip2)

        # calculate transport plans
        tplan <- transport::transport(transport::pgrid(snip1), transport::pgrid(snip2), p = 2)

        results[[length(results) + 1]] <- tplan

      }
    }else{
      # calculate transport plan between full images
      tplan <- transport::transport(transport::pgrid(picA), transport::pgrid(picB), p = 2)

      # add to results
      results[[length(results) + 1]] <- tplan
    }

  }

  # save if it is true
  if (save){
    save(results, file = file.path(output_path, paste("Tplans_", output_name, ".RData")))
  }


  return(results)
}
