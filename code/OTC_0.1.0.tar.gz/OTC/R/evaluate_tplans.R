#' Evaluation of transport plans
#'
#' @param data_path location where .RData sets of transport plans can be found
#' @param data_list list of name of data sets
#' @param pxsize size of pixels in original image in nm
#' @param dim list of number of pixels in both directions, if length of list is 1 it is assumed that the
#' the pixel grid is quadratic
#' @param save If you want to save the results, defaults to TRUE
#' @param output_path Where to save the results
#' @param output_name Name of data set, full name will be OTC_<output_name>.RData
#' @return Dataframe with the columns class, i, t, OTC




evaluate_tplans <- function(data_path, data_list, pxsize, dim, output_path="", output_name="", save=TRUE){

  # check if save is true and output_path given
  if (save & output_path==""){stop("Please provide an output_path if you want to save the results!")}

  # assume squared format if only one dimension is given
  if (length(dim) == 1){dim <- rep(dim[1], 2)}

  # set up results data frame
  results <- data.frame(class=character(0), no_pic=integer(0), t=numeric(0), OTC=numeric(0))

  for (i in 1:length(data_list)){ # go over all datasets
    env <- new.env()
    nm <- load(file.path(data_path, data_list[i]), env)[1]
    tplans <- env[[nm]]
    for (j in 1:length(tplans)){# go over all transport plans in one dataset
      tplan <- tplans[[j]]
      # calculate distance if not already included in tplan
      if (!"dist" %in% colnames(tplan)){
        coord <- as.data.frame(arrayInd(tplan$from, c(dim[1], dim[2])) - arrayInd(tplan$to, c(dim[1],dim[2])))
        tplan$dist <- sqrt(pxsize^2*coord$V1^2 + pxsize^2*coord$V2^2)
      }

      # evaluate OTC for diffenten t
      max_dim <- max(dim)
      for (t in seq(0,pxsize*max_dim*sqrt(2)/2,15)){
        #print(data.frame(class = gsub("Tplans_", "", gsub(".RData", "", data_list[i])), no_pic = j, t = t, OTC = sum(tplan[tplan$dist <=t,]$mass)))
        results <- rbind(results, data.frame(class = gsub("Tplans_", "", gsub(".RData", "", data_list[i])), no_pic = j, t = t, OTC = sum(tplan[tplan$dist <=t,]$mass)))
      }
    }
  }

  if (save){
    save(results, file = file.path(output_path, paste("OTC_", output_name, ".RData", sep="")))
  }
  return(results)

}
