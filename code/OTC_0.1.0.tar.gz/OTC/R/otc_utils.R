# load needed libraries
library(tiff)
library(transport)
library(gdata)
library(fields)
library(ggplot2)
library(MASS)

# convert RGB to grayscale
RGBtoGray <- function(P){
  if(!is.na(dim(P)[3])){
    0.2989 * P[, , 1] + 0.587 * P[, , 2] + 0.114 * P[, , 3]
  } else  return(P)
}
