#' A function to calculate a bunch of transport plans between coordinates.
#'
#' @description
#' This function calculates a bunch of transport plans between two sets of coordinates
#'
#' @param data_path location to folder that contains the images in tiff format+
#' @param picsA list of names of pictures of type A
#' @param picsB list of names of pictures of type B
#' @param pxsize size of pixels in nm (default 15)
#' @param save If you want to save the results, defaults to TRUE
#' @param output_path Where to save the results
#' @param output_name Name of data set, full name will be Tplans_<output_name>_coord.RData
#' @return Returns a list with transport plans with distances



source("./R/otc_utils.R")

calculate_tplans_coordinates <- function(data_path, picsA, picsB, pxsize = 15, output_path="", output_name="", save=TRUE){

  # check if save is true and output_path given
  if (save & output_path==""){stop("Please provide an output_path if you want to save the results!")}

  # check for length in items in picsA and picsB
  n <- length(picsA)
  if (n != length(picsB)){
    stop("Unequal number of pics of type A and B")
  }

  # set up results
  results <- list()

  for (i in 1:n){
    print(paste("Processing", i, "out of", n, "...", sep = " "))

    # read coordinates
    # TO-DO Add try and catch maybe?
    coordA <- gdata::read.xls(file.path(data_path, picsA[i]))
    coordB <- gdata::read.xls(file.path(data_path, picsB[i]))

    # calculate costmatrix
    costm <- fields::rdist(coordA, coordB)

    # set up uniform distributins for coordA and coordB, as a uniform dist over all coordinates are assumed
    unifA <- rep(1/nrow(coordA), nrow(coordA))
    unifB <- rep(1/nrow(coordB), nrow(coordB))

    # calculate transport plan between lists of coordinates
    tplan <- transport::transport(unifA, unifB, costm=costm^2)

    # calculate distances
    tplan$dist <- 0
    for (j in 1:nrow(tplan)){
      tplan[j,]$dist <- pxsize * costm[tplan[j,]$from, tplan[j,]$to]
    }

    # print(colnames(tplan))

    # add to results
    results[[length(results) + 1]] <- tplan

}

  # save if it is true
  if (save){
    save(results, file = file.path(output_path, paste("Tplans_", output_name, "_coord.RData", sep="")))
  }


  return(results)
}
